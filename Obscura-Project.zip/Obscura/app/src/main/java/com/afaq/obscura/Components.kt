package com.afaq.obscura

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import java.util.Locale

object Pal {
    val Bg = Color(0xFF0D1117)
    val Surface = Color(0xFF161B22)
    val Surface2 = Color(0xFF212934)
    val Text = Color(0xFFE6EDF3)
    val Muted = Color(0xFF8B98A9)
    val Error = Color(0xFFFF6B6B)
    val Home = Color(0xFF00BFA5)
    val Photos = Color(0xFF3D8BFF)
    val Videos = Color(0xFFFF5C7A)
    val Files = Color(0xFFFFB020)
    val Settings = Color(0xFF9B6BFF)
}

enum class Sec(val label: String, val color: Color) {
    HOME("Home", Pal.Home),
    PHOTOS("Photos", Pal.Photos),
    VIDEOS("Videos", Pal.Videos),
    FILES("Files", Pal.Files),
    SETTINGS("Settings", Pal.Settings)
}

@Composable
fun ObscuraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pal.Home, onPrimary = Color.Black,
            secondary = Pal.Photos, background = Pal.Bg, onBackground = Pal.Text,
            surface = Pal.Surface, onSurface = Pal.Text,
            surfaceVariant = Pal.Surface2, onSurfaceVariant = Pal.Muted, error = Pal.Error
        ),
        content = content
    )
}

/** Hand-drawn section icons (no icon library needed). */
@Composable
fun SecIcon(sec: Sec, tint: Color, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val st = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (sec) {
            Sec.HOME -> {
                val p = Path().apply {
                    moveTo(w * .12f, h * .48f); lineTo(w * .5f, h * .14f); lineTo(w * .88f, h * .48f)
                    moveTo(w * .22f, h * .42f); lineTo(w * .22f, h * .86f)
                    lineTo(w * .78f, h * .86f); lineTo(w * .78f, h * .42f)
                }
                drawPath(p, tint, style = st)
            }
            Sec.PHOTOS -> {
                drawRoundRect(tint, Offset(w * .1f, h * .2f), Size(w * .8f, h * .6f), CornerRadius(w * .1f), style = st)
                drawCircle(tint, w * .07f, Offset(w * .36f, h * .4f))
                val p = Path().apply {
                    moveTo(w * .14f, h * .74f); lineTo(w * .4f, h * .55f); lineTo(w * .58f, h * .68f)
                    lineTo(w * .72f, h * .52f); lineTo(w * .88f, h * .7f)
                }
                drawPath(p, tint, style = st)
            }
            Sec.VIDEOS -> {
                drawRoundRect(tint, Offset(w * .1f, h * .2f), Size(w * .8f, h * .6f), CornerRadius(w * .1f), style = st)
                val p = Path().apply {
                    moveTo(w * .42f, h * .36f); lineTo(w * .42f, h * .64f); lineTo(w * .66f, h * .5f); close()
                }
                drawPath(p, tint)
            }
            Sec.FILES -> {
                val p = Path().apply {
                    moveTo(w * .1f, h * .28f); lineTo(w * .38f, h * .28f); lineTo(w * .46f, h * .38f)
                    lineTo(w * .9f, h * .38f); lineTo(w * .9f, h * .78f); lineTo(w * .1f, h * .78f); close()
                }
                drawPath(p, tint, style = st)
            }
            Sec.SETTINGS -> {
                for ((i, y) in listOf(.25f, .5f, .75f).withIndex()) {
                    drawLine(tint, Offset(w * .12f, h * y), Offset(w * .88f, h * y), strokeWidth = w * .09f, cap = StrokeCap.Round)
                    val x = listOf(.65f, .35f, .6f)[i]
                    drawCircle(Pal.Bg, w * .11f, Offset(w * x, h * y))
                    drawCircle(tint, w * .11f, Offset(w * x, h * y), style = st)
                }
            }
        }
    }
}

/** Thumbnail box: shows a cached bitmap immediately, otherwise loads it off the main thread. */
@Composable
fun Thumb(key: String, modifier: Modifier = Modifier, load: () -> Bitmap?) {
    var bmp by remember(key) { mutableStateOf(Thumbs.peek(key)) }
    LaunchedEffect(key) {
        if (bmp == null) bmp = Thumbs.load(key, load)
    }
    Box(modifier.background(Pal.Surface2)) {
        bmp?.let {
            Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
    }
}

fun fmtSize(b: Long): String {
    if (b < 1024) return "$b B"
    val kb = b / 1024.0
    if (kb < 1024) return String.format(Locale.US, "%.0f KB", kb)
    val mb = kb / 1024
    if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb)
    return String.format(Locale.US, "%.2f GB", mb / 1024)
}

fun fmtDur(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%d:%02d", m, sec)
}

fun fileColor(name: String): Color = when (name.substringAfterLast('.', "").lowercase()) {
    "pdf" -> Color(0xFFFF5C5C)
    "doc", "docx", "txt", "rtf", "odt" -> Color(0xFF4C9AFF)
    "xls", "xlsx", "csv", "ods" -> Color(0xFF3DDC84)
    "ppt", "pptx" -> Color(0xFFFF8A3D)
    "zip", "rar", "7z", "tar", "gz" -> Color(0xFFFFB020)
    "mp3", "wav", "m4a", "aac", "flac", "ogg" -> Color(0xFFB36BFF)
    "apk" -> Color(0xFF00BFA5)
    else -> Color(0xFF8B98A9)
}
