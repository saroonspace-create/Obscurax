package com.afaq.obscura

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: VaultViewModel, host: Host) {
    var sub by remember { mutableStateOf<String?>(null) }
    BackHandler(sub != null) { sub = null }

    if (sub == "pin") {
        SetupFlow(SetupMode.PIN, vm, host, onDone = { sub = null; vm.message = "PIN changed" }, onCancel = { sub = null })
        return
    }
    if (sub == "pattern") {
        SetupFlow(SetupMode.PATTERN, vm, host, onDone = { sub = null; vm.message = "Pattern changed" }, onCancel = { sub = null })
        return
    }

    var bio by remember { mutableStateOf(vm.security.bioEnabled) }
    val bioAvailable = host.canBiometric()
    val tick = vm.resumeTick
    val allFiles = remember(tick) { host.hasAllFilesAccess() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SecIcon(Sec.SETTINGS, Pal.Settings, Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
        }

        SettingsCard("Security", Pal.Settings) {
            SettingRow("Change PIN", "4 to 6 digits", Pal.Settings) { sub = "pin" }
            SettingRow("Change pattern", "Connect at least 4 dots", Pal.Settings) { sub = "pattern" }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Fingerprint unlock", color = Pal.Text, fontWeight = FontWeight.Medium)
                    Text(if (bioAvailable) "Unlock with your fingerprint" else "No fingerprint enrolled on this phone", color = Pal.Muted, fontSize = 12.sp)
                }
                Switch(
                    checked = bio, enabled = bioAvailable,
                    onCheckedChange = { want ->
                        if (want) {
                            host.authenticate("Confirm your fingerprint") { ok, msg ->
                                if (ok) { vm.security.bioEnabled = true; bio = true }
                                else if (msg != null) vm.message = msg
                            }
                        } else { vm.security.bioEnabled = false; bio = false }
                    },
                    colors = SwitchDefaults.colors(checkedTrackColor = Pal.Settings, checkedThumbColor = Color.White)
                )
            }
            Button(
                onClick = { vm.lock() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Pal.Settings, contentColor = Color.Black)
            ) { Text("Lock now", fontWeight = FontWeight.SemiBold) }
        }

        SettingsCard("Privacy & storage", Pal.Home) {
            InfoRow("Vault size", fmtSize(vm.repo.totalSize()) + " \u2022 ${vm.repo.items.size} items")
            InfoRow("Screenshots", "Blocked inside Obscura")
            InfoRow("Internet", "Not used. The app has no network access")
            if (Build.VERSION.SDK_INT >= 30) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Delete originals without asking", color = Pal.Text, fontWeight = FontWeight.Medium)
                        Text(
                            if (allFiles) "On. Locked files vanish from the gallery silently"
                            else "Off. Android shows a confirmation each time you lock files",
                            color = Pal.Muted, fontSize = 12.sp
                        )
                    }
                    if (!allFiles) {
                        Button(
                            onClick = { host.openAllFilesSettings() }, shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Pal.Home, contentColor = Color.Black)
                        ) { Text("Enable") }
                    } else Text("\u2713", color = Pal.Home, fontSize = 22.sp)
                }
            }
        }

        SettingsCard("Help line & FAQ", Pal.Files) {
            Text("Questions, problems or feedback? Contact:", color = Pal.Muted, fontSize = 13.sp)
            Text("Afaq Ahmad", color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("meafaq17@gmail.com", color = Pal.Files, fontSize = 14.sp)
            Button(
                onClick = { host.sendEmail() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Pal.Files, contentColor = Color.Black)
            ) { Text("Send email", fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(6.dp))
            Faq("Where are my locked files stored?", "Inside Obscura's private storage. The gallery and other apps cannot see them.")
            Faq("Why does Android ask before removing originals?", "Android 11+ requires your approval when an app deletes photos or videos it did not create. Turn on \"Delete originals without asking\" above to skip the prompt.")
            Faq("I forgot my PIN. What now?", "Unlock with your pattern or fingerprint, then set a new PIN in Settings. Credentials are stored only on this phone and cannot be recovered. If you forget everything, reinstalling the app is the only way in, and it erases the vault.")
            Faq("Are my files deleted if I uninstall?", "Yes. Restore anything you want to keep to the gallery first.")
            Faq("How do I get a file out?", "Open the Photos, Videos or Files tab, long-press items to select them and tap Restore. Restored files go to Pictures/Obscura, Movies/Obscura or Downloads/Obscura.")
        }

        SettingsCard("About", Pal.Videos) {
            InfoRow("Obscura", "Version 2.0")
            Text("A private, offline vault for your photos, videos and files.", color = Pal.Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SettingsCard(title: String, color: Color, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(color.copy(alpha = .10f))
            .border(1.dp, color.copy(alpha = .55f), RoundedCornerShape(20.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
private fun SettingRow(title: String, sub: String, color: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Pal.Text, fontWeight = FontWeight.Medium)
            Text(sub, color = Pal.Muted, fontSize = 12.sp)
        }
        Text("\u203A", color = color, fontSize = 24.sp)
    }
}

@Composable
private fun InfoRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, color = Pal.Muted, fontSize = 13.sp)
        Text(v, color = Pal.Text, fontSize = 13.sp, modifier = Modifier.weight(1f).padding(start = 12.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End)
    }
}

@Composable
private fun Faq(q: String, a: String) {
    var open by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Pal.Surface)
            .clickable { open = !open }.padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(q, color = Pal.Text, fontWeight = FontWeight.Medium, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(if (open) "\u2212" else "+", color = Pal.Files, fontSize = 20.sp)
        }
        if (open) {
            Spacer(Modifier.height(6.dp))
            Text(a, color = Pal.Muted, fontSize = 13.sp)
        }
    }
}
