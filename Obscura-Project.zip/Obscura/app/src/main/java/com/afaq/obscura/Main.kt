package com.afaq.obscura

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ViewerReq(val items: List<VaultItem>, val start: Int)

@Composable
fun ObscuraRoot(vm: VaultViewModel, host: Host) {
    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        when {
            !vm.setupDone -> SetupFlow(SetupMode.FULL, vm, host, onDone = { vm.finishSetup() })
            !vm.unlocked -> UnlockScreen(vm, host)
            else -> MainShell(vm, host)
        }
    }
}

@Composable
fun MainShell(vm: VaultViewModel, host: Host) {
    var tab by remember { mutableStateOf(Sec.HOME) }
    var viewer by remember { mutableStateOf<ViewerReq?>(null) }
    var picker by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }

    LaunchedEffect(vm.message) {
        vm.message?.let { snack.showSnackbar(it); vm.message = null }
    }
    BackHandler(enabled = viewer != null || picker || tab != Sec.HOME) {
        when {
            viewer != null -> viewer = null
            picker -> picker = false
            else -> tab = Sec.HOME
        }
    }

    Box(Modifier.fillMaxSize()) {
        val v = viewer
        if (v != null) {
            ViewerScreen(v.items, v.start, vm, host, onClose = { viewer = null })
        } else if (picker) {
            GalleryPicker(vm, host, onClose = { picker = false })
        } else {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        Sec.HOME -> HomeScreen(vm, onOpen = { tab = it }, onImportMedia = { picker = true },
                            onImportFiles = { host.pickFiles { vm.importFiles(it) } })
                        Sec.SETTINGS -> SettingsScreen(vm, host)
                        else -> SectionScreen(tab, vm, host,
                            onImport = {
                                if (tab == Sec.FILES) host.pickFiles { vm.importFiles(it) } else picker = true
                            },
                            onOpen = { list, i -> viewer = ViewerReq(list, i) })
                    }
                }
                NavigationBar(containerColor = Pal.Surface) {
                    for (s in Sec.values()) {
                        NavigationBarItem(
                            selected = tab == s, onClick = { tab = s },
                            icon = { SecIcon(s, if (tab == s) Color.Black else s.color) },
                            label = { Text(s.label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black, selectedTextColor = s.color,
                                indicatorColor = s.color,
                                unselectedIconColor = s.color, unselectedTextColor = Pal.Muted
                            )
                        )
                    }
                }
            }
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).padding(bottom = 84.dp))
        vm.busy?.let { BusyOverlay(it) }
    }
}

@Composable
fun BusyOverlay(text: String) {
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = .65f)).clickable(enabled = true) {},
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.clip(RoundedCornerShape(20.dp)).background(Pal.Surface).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator(color = Pal.Home)
            Spacer(Modifier.height(14.dp))
            Text(text, color = Pal.Text)
        }
    }
}

// ---------------------------------------------------------------- Home
@Composable
fun HomeScreen(vm: VaultViewModel, onOpen: (Sec) -> Unit, onImportMedia: () -> Unit, onImportFiles: () -> Unit) {
    val items = vm.repo.items
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Obscura", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
                Text("${items.size} items locked \u2022 ${fmtSize(vm.repo.totalSize())}", color = Pal.Muted, fontSize = 14.sp)
            }
            IconButton(onClick = { vm.lock() }) { Icon(Icons.Default.Lock, "Lock now", tint = Pal.Home) }
        }
        Spacer(Modifier.height(18.dp))
        for ((s, k) in listOf(Sec.PHOTOS to Kind.IMAGE, Sec.VIDEOS to Kind.VIDEO, Sec.FILES to Kind.FILE)) {
            val list = items.filter { it.kind == k }
            SectionCard(s, list.size, list.sumOf { it.size }) { onOpen(s) }
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = onImportMedia, modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Pal.Photos, contentColor = Color.Black)
        ) { Text("Lock photos & videos", fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onImportFiles, modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Pal.Files, contentColor = Color.Black)
        ) { Text("Lock other files", fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun SectionCard(s: Sec, count: Int, bytes: Long, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(s.color.copy(alpha = .30f), Pal.Surface)))
            .border(1.dp, s.color.copy(alpha = .6f), RoundedCornerShape(22.dp))
            .clickable(onClick = onClick).padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(s.color.copy(alpha = .22f)), contentAlignment = Alignment.Center) {
            SecIcon(s, s.color, Modifier.size(28.dp))
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(s.label, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Pal.Text)
            Text("$count items \u2022 ${fmtSize(bytes)}", fontSize = 13.sp, color = Pal.Muted)
        }
        Text("\u203A", fontSize = 28.sp, color = s.color)
    }
}

// ---------------------------------------------------------------- Section (photos / videos / files)
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SectionScreen(
    sec: Sec, vm: VaultViewModel, host: Host,
    onImport: () -> Unit, onOpen: (List<VaultItem>, Int) -> Unit
) {
    val kind = when (sec) { Sec.PHOTOS -> Kind.IMAGE; Sec.VIDEOS -> Kind.VIDEO; else -> Kind.FILE }
    val list = vm.repo.items.filter { it.kind == kind }
    val selected = remember(sec) { mutableStateListOf<String>() }
    var confirm by remember { mutableStateOf(false) }
    BackHandler(selected.isNotEmpty()) { selected.clear() }

    fun toggle(id: String) { if (id in selected) selected.remove(id) else selected.add(id) }

    Column(Modifier.fillMaxSize()) {
        if (selected.isEmpty()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                SecIcon(sec, sec.color, Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(sec.label, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
                    Text("${list.size} items", fontSize = 13.sp, color = Pal.Muted)
                }
                Button(
                    onClick = onImport, shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = sec.color, contentColor = Color.Black)
                ) { Text("+ Lock", fontWeight = FontWeight.SemiBold) }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().background(sec.color.copy(alpha = .22f)).padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { selected.clear() }) { Icon(Icons.Default.Close, "Cancel", tint = Pal.Text) }
                Text("${selected.size} selected", color = Pal.Text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                TextButton(onClick = { selected.clear(); selected.addAll(list.map { it.id }) }) { Text("All", color = sec.color) }
                TextButton(onClick = { vm.restore(selected.toList(), host) { selected.clear() } }) { Text("Restore", color = sec.color) }
                TextButton(onClick = { confirm = true }) { Text("Delete", color = Pal.Error) }
            }
        }

        if (list.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(84.dp).clip(CircleShape).background(sec.color.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                    SecIcon(sec, sec.color, Modifier.size(42.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text("Nothing here yet", color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("Tap \"+ Lock\" to move ${sec.label.lowercase()} into your vault.", color = Pal.Muted, fontSize = 14.sp)
            }
        } else if (kind == Kind.FILE) {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list, key = { it.id }) { item ->
                    val col = fileColor(item.name)
                    val on = item.id in selected
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(if (on) col.copy(alpha = .30f) else Pal.Surface)
                            .border(if (on) 2.dp else 1.dp, col.copy(alpha = if (on) 1f else .55f), RoundedCornerShape(16.dp))
                            .combinedClickable(
                                onClick = { if (selected.isNotEmpty()) toggle(item.id) else onOpen(list, list.indexOf(item)) },
                                onLongClick = { toggle(item.id) }
                            ).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(col.copy(alpha = .25f)), contentAlignment = Alignment.Center) {
                            Text(item.name.substringAfterLast('.', "FILE").take(4).uppercase(), color = col, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.name, color = Pal.Text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Text("${fmtSize(item.size)} \u2022 ${fmtDate(item.added)}", color = Pal.Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                GridCells.Adaptive(104.dp), contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(list, key = { it.id }) { item ->
                    val on = item.id in selected
                    val shape = RoundedCornerShape(14.dp)
                    Box(
                        Modifier.aspectRatio(1f).clip(shape)
                            .border(if (on) 3.dp else 1.5.dp, if (on) Color.White else sec.color.copy(alpha = .75f), shape)
                            .combinedClickable(
                                onClick = { if (selected.isNotEmpty()) toggle(item.id) else onOpen(list, list.indexOf(item)) },
                                onLongClick = { toggle(item.id) }
                            )
                    ) {
                        Thumb("f:${item.id}", Modifier.fillMaxSize()) {
                            if (item.kind == Kind.VIDEO) Thumbs.videoFile(vm.repo.file(item.id), 320)
                            else Thumbs.imageFile(vm.repo.file(item.id), 320)
                        }
                        if (item.kind == Kind.VIDEO) {
                            Text(
                                "\u25B6 ${fmtDur(item.duration)}", color = Color.White, fontSize = 11.sp,
                                modifier = Modifier.align(Alignment.BottomStart).padding(6.dp).clip(RoundedCornerShape(8.dp))
                                    .background(Pal.Videos.copy(alpha = .9f)).padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        if (on) {
                            Box(Modifier.fillMaxSize().background(sec.color.copy(alpha = .35f)))
                            Box(
                                Modifier.align(Alignment.TopEnd).padding(6.dp).size(24.dp).clip(CircleShape).background(Color.White),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Default.Check, null, tint = Color.Black, modifier = Modifier.size(16.dp)) }
                        }
                    }
                }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = Pal.Surface,
            title = { Text("Delete ${selected.size} item(s)?", color = Pal.Text) },
            text = { Text("They will be permanently deleted from the vault. This cannot be undone.", color = Pal.Muted) },
            confirmButton = {
                TextButton(onClick = { vm.delete(selected.toList()); selected.clear(); confirm = false }) { Text("Delete", color = Pal.Error) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel", color = Pal.Muted) } }
        )
    }
}

fun fmtDate(ms: Long): String = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(ms))
