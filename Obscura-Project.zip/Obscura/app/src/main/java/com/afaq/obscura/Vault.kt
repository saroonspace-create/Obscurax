package com.afaq.obscura

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

enum class Kind { IMAGE, VIDEO, FILE }

data class VaultItem(
    val id: String,
    val name: String,
    val mime: String,
    val kind: Kind,
    val size: Long,
    val added: Long,
    val duration: Long
)

/** Files live in the app's private storage, invisible to the gallery and other apps. */
class VaultRepo(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "vault").apply { mkdirs() }
    private val indexFile = File(dir, "index.json")
    val items = mutableStateListOf<VaultItem>()

    init { load() }

    fun file(id: String) = File(dir, id)
    fun find(id: String): VaultItem? = items.firstOrNull { it.id == id }
    fun totalSize(): Long = items.sumOf { it.size }

    private fun load() {
        try {
            if (!indexFile.exists()) return
            val arr = JSONArray(indexFile.readText())
            val list = ArrayList<VaultItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                if (!file(id).exists()) continue
                list.add(
                    VaultItem(
                        id, o.getString("name"), o.getString("mime"),
                        Kind.valueOf(o.getString("kind")),
                        o.getLong("size"), o.getLong("added"), o.optLong("duration", 0L)
                    )
                )
            }
            items.addAll(list.sortedByDescending { it.added })
        } catch (_: Exception) {
        }
    }

    private fun persist() {
        try {
            val arr = JSONArray()
            for (it in items.toList()) {
                arr.put(
                    JSONObject().put("id", it.id).put("name", it.name).put("mime", it.mime)
                        .put("kind", it.kind.name).put("size", it.size).put("added", it.added)
                        .put("duration", it.duration)
                )
            }
            val tmp = File(dir, "index.tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(indexFile)
        } catch (_: Exception) {
        }
    }

    fun addAll(newItems: List<VaultItem>) {
        if (newItems.isEmpty()) return
        items.addAll(0, newItems)
        persist()
    }

    fun remove(ids: List<String>) {
        val set = ids.toSet()
        for (id in set) file(id).delete()
        items.removeAll { it.id in set }
        persist()
    }

    private fun queryName(uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    private fun guessMime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    /** Copies a file into the vault. Returns null on failure (partial copy is removed). */
    fun copyIn(uri: Uri, knownName: String?, expectedSize: Long): VaultItem? {
        val id = UUID.randomUUID().toString()
        val out = file(id)
        try {
            val name = knownName ?: queryName(uri) ?: "file_$id"
            val input = ctx.contentResolver.openInputStream(uri) ?: return null
            input.use { i -> out.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
            if (expectedSize > 0 && out.length() != expectedSize) {
                out.delete(); return null
            }
            var mime = ctx.contentResolver.getType(uri) ?: guessMime(name)
            if (mime == "application/octet-stream") mime = guessMime(name)
            val kind = when {
                mime.startsWith("image/") -> Kind.IMAGE
                mime.startsWith("video/") -> Kind.VIDEO
                else -> Kind.FILE
            }
            var duration = 0L
            if (kind == Kind.VIDEO) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(out.absolutePath)
                    duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                } catch (_: Exception) {
                } finally {
                    try { r.release() } catch (_: Exception) {}
                }
            }
            return VaultItem(id, name, mime, kind, out.length(), System.currentTimeMillis(), duration)
        } catch (_: Exception) {
            out.delete()
            return null
        }
    }

    /** Copies a vault item back to the public gallery / Downloads. */
    fun restoreToGallery(item: VaultItem): Boolean {
        val src = file(item.id)
        if (!src.exists()) return false
        return try {
            val baseDir = when (item.kind) {
                Kind.IMAGE -> Environment.DIRECTORY_PICTURES
                Kind.VIDEO -> Environment.DIRECTORY_MOVIES
                Kind.FILE -> Environment.DIRECTORY_DOWNLOADS
            }
            if (Build.VERSION.SDK_INT >= 29) {
                val collection: Uri = when (item.kind) {
                    Kind.IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    Kind.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    Kind.FILE -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
                }
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, item.name)
                    put(MediaStore.MediaColumns.MIME_TYPE, item.mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "$baseDir/Obscura")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = ctx.contentResolver.insert(collection, values) ?: return false
                val os = ctx.contentResolver.openOutputStream(uri)
                if (os == null) {
                    ctx.contentResolver.delete(uri, null, null); return false
                }
                os.use { o -> src.inputStream().use { it.copyTo(o, 256 * 1024) } }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                ctx.contentResolver.update(uri, values, null, null)
                true
            } else {
                val pub = File(Environment.getExternalStoragePublicDirectory(baseDir), "Obscura")
                pub.mkdirs()
                var dest = File(pub, item.name)
                if (dest.exists()) dest = File(pub, "${System.currentTimeMillis()}_${item.name}")
                src.copyTo(dest, overwrite = false)
                MediaScannerConnection.scanFile(ctx, arrayOf(dest.path), arrayOf(item.mime), null)
                true
            }
        } catch (_: Exception) {
            false
        }
    }
}
