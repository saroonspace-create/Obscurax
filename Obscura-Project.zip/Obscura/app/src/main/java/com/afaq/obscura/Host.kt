package com.afaq.obscura

import android.net.Uri

/** Things only the Activity can do (permissions, system dialogs, biometrics). */
interface Host {
    fun ensureReadAccess(cb: (Boolean) -> Unit)
    fun ensureWriteAccess(cb: (Boolean) -> Unit)
    fun requestDelete(uris: List<Uri>, onDone: (Boolean) -> Unit)
    fun pickFiles(cb: (List<Uri>) -> Unit)
    fun sendEmail()
    fun canBiometric(): Boolean
    fun authenticate(title: String, cb: (Boolean, String?) -> Unit)
    fun openAllFilesSettings()
    fun hasAllFilesAccess(): Boolean
}
