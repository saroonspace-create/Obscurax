package com.afaq.obscura

import android.app.Application
import android.net.Uri
import android.provider.DocumentsContract
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VaultViewModel(app: Application) : AndroidViewModel(app) {
    val security = SecurityStore(app)
    val repo = VaultRepo(app)

    var setupDone by mutableStateOf(security.isSetup)
    var unlocked by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf<String?>(null)
    var resumeTick by mutableIntStateOf(0)

    /** True while the app itself is opening a system screen (permission, picker, delete dialog...). */
    var suppressLock = false
    var stoppedWhileSuppressed = false

    fun unlock() { security.clearFails(); unlocked = true }
    fun lock() { unlocked = false }
    fun finishSetup() { setupDone = true; unlocked = true }

    fun importMedia(host: Host, picks: List<GalleryMedia>) {
        if (picks.isEmpty()) return
        viewModelScope.launch {
            busy = "Importing 0/${picks.size}"
            val added = ArrayList<VaultItem>()
            val copied = ArrayList<Uri>()
            for ((i, p) in picks.withIndex()) {
                val item = withContext(Dispatchers.IO) { repo.copyIn(p.uri, p.name, p.size) }
                if (item != null) { added.add(item); copied.add(p.uri) }
                busy = "Importing ${i + 1}/${picks.size}"
            }
            repo.addAll(added)
            busy = null
            if (copied.isEmpty()) {
                message = "Import failed"
                return@launch
            }
            host.requestDelete(copied) { ok ->
                message = if (ok) "Locked ${copied.size} item(s) and removed them from the gallery"
                else "Locked ${copied.size} item(s), but the originals are still in the gallery"
            }
        }
    }

    fun importFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val cr = getApplication<Application>().contentResolver
            busy = "Importing 0/${uris.size}"
            val added = ArrayList<VaultItem>()
            var removed = 0
            for ((i, u) in uris.withIndex()) {
                val item = withContext(Dispatchers.IO) { repo.copyIn(u, null, -1L) }
                if (item != null) {
                    added.add(item)
                    val ok = withContext(Dispatchers.IO) {
                        try { DocumentsContract.deleteDocument(cr, u) } catch (_: Exception) { false }
                    }
                    if (ok) removed++
                }
                busy = "Importing ${i + 1}/${uris.size}"
            }
            repo.addAll(added)
            busy = null
            message = when {
                added.isEmpty() -> "Import failed"
                removed == added.size -> "Locked ${added.size} file(s) and removed the originals"
                else -> "Locked ${added.size} file(s). Originals could not be removed automatically, please delete them manually"
            }
        }
    }

    fun delete(ids: List<String>) {
        repo.remove(ids)
        message = "Deleted ${ids.size} item(s)"
    }

    fun restore(ids: List<String>, host: Host, done: () -> Unit) {
        host.ensureWriteAccess { ok ->
            if (!ok) {
                message = "Storage permission is needed to restore files"
                return@ensureWriteAccess
            }
            viewModelScope.launch {
                busy = "Restoring..."
                var n = 0
                for (id in ids) {
                    val item = repo.find(id) ?: continue
                    val r = withContext(Dispatchers.IO) { repo.restoreToGallery(item) }
                    if (r) { repo.remove(listOf(id)); n++ }
                }
                busy = null
                message = if (n == ids.size) "Restored $n item(s) to your gallery / Downloads (Obscura folder)"
                else "Restored $n of ${ids.size} item(s)"
                done()
            }
        }
    }
}
