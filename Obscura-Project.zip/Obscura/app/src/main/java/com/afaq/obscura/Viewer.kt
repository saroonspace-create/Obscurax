package com.afaq.obscura

import android.graphics.Bitmap
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ViewerScreen(items: List<VaultItem>, start: Int, vm: VaultViewModel, host: Host, onClose: () -> Unit) {
    val pager = rememberPagerState(initialPage = start.coerceIn(0, items.size - 1)) { items.size }
    var zoomed by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val current = items[pager.currentPage.coerceIn(0, items.size - 1)]
    val accent = when (current.kind) { Kind.IMAGE -> Pal.Photos; Kind.VIDEO -> Pal.Videos; Kind.FILE -> fileColor(current.name) }

    LaunchedEffect(pager.currentPage) { zoomed = false }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.fillMaxSize(), userScrollEnabled = !zoomed) { page ->
            val item = items[page]
            val file = vm.repo.file(item.id)
            when (item.kind) {
                Kind.IMAGE -> ZoomableImage(file) { zoomed = it }
                Kind.VIDEO -> if (pager.currentPage == page) VideoPlayer(file, Modifier.fillMaxSize())
                else Thumb("f:${item.id}", Modifier.fillMaxSize()) { Thumbs.videoFile(file, 320) }
                Kind.FILE -> FileInfoPage(item)
            }
        }
        TopBar(current, pager.currentPage + 1, items.size, accent, onClose,
            onRestore = { vm.restore(listOf(current.id), host) { onClose() } },
            onDelete = { confirm = true })
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = Pal.Surface,
            title = { Text("Delete this item?", color = Pal.Text) },
            text = { Text("It will be permanently deleted from the vault.", color = Pal.Muted) },
            confirmButton = {
                TextButton(onClick = { vm.delete(listOf(current.id)); confirm = false; onClose() }) { Text("Delete", color = Pal.Error) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel", color = Pal.Muted) } }
        )
    }
}

@Composable
private fun BoxScope.TopBar(
    item: VaultItem, index: Int, total: Int, accent: Color,
    onClose: () -> Unit, onRestore: () -> Unit, onDelete: () -> Unit
) {
    Row(
        Modifier.align(Alignment.TopCenter).fillMaxWidth().background(Color.Black.copy(alpha = .6f))
            .statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
        Column(Modifier.weight(1f)) {
            Text(item.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text("$index / $total \u2022 ${fmtSize(item.size)}", color = Color.White.copy(alpha = .7f), fontSize = 12.sp)
        }
        TextButton(onClick = onRestore) { Text("Restore", color = accent, fontWeight = FontWeight.SemiBold) }
        TextButton(onClick = onDelete) { Text("Delete", color = Pal.Error, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
fun FileInfoPage(item: VaultItem) {
    val col = fileColor(item.name)
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(110.dp).clip(RoundedCornerShape(28.dp)).background(col.copy(alpha = .22f)), contentAlignment = Alignment.Center) {
            Text(item.name.substringAfterLast('.', "FILE").take(5).uppercase(), color = col, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(20.dp))
        Text(item.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text("${fmtSize(item.size)} \u2022 ${item.mime}", color = Color.White.copy(alpha = .65f), fontSize = 13.sp)
        Text("Locked on ${fmtDate(item.added)}", color = Color.White.copy(alpha = .65f), fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Text("Use Restore to put this file back in Downloads.", color = col, fontSize = 13.sp)
    }
}

@Composable
fun ZoomableImage(file: File, onZoom: (Boolean) -> Unit) {
    var bmp by remember(file) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(file) { bmp = withContext(Dispatchers.IO) { Thumbs.imageFile(file, 2048) } }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val multi = ev.changes.size > 1
                        if (multi || scale > 1f) {
                            val z = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            scale = (scale * z).coerceIn(1f, 5f)
                            if (scale > 1f) {
                                val mx = size.width * (scale - 1f) / 2f
                                val my = size.height * (scale - 1f) / 2f
                                val o = offset + pan
                                offset = Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
                            } else offset = Offset.Zero
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                            onZoom(scale > 1f)
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    scale = if (scale > 1f) 1f else 2.5f
                    offset = Offset.Zero
                    onZoom(scale > 1f)
                })
            }
    ) {
        bmp?.let {
            Image(
                it.asImageBitmap(), null,
                Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
fun VideoPlayer(file: File, modifier: Modifier = Modifier) {
    AndroidView(
        factory = { c ->
            val frame = FrameLayout(c)
            val vv = VideoView(c)
            val mc = MediaController(c)
            mc.setAnchorView(frame)
            vv.setMediaController(mc)
            vv.setVideoPath(file.absolutePath)
            vv.setOnPreparedListener { vv.start() }
            frame.addView(
                vv,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER)
            )
            frame
        },
        modifier = modifier,
        onRelease = { f -> (f.getChildAt(0) as? VideoView)?.stopPlayback() }
    )
}
