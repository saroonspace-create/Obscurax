package com.afaq.obscura

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

class PickFiles : ActivityResultContract<Unit, List<Uri>>() {
    override fun createIntent(context: Context, input: Unit): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)

    override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> {
        if (resultCode != android.app.Activity.RESULT_OK || intent == null) return emptyList()
        val out = ArrayList<Uri>()
        intent.clipData?.let { for (i in 0 until it.itemCount) out.add(it.getItemAt(i).uri) }
        if (out.isEmpty()) intent.data?.let { out.add(it) }
        return out
    }
}

class MainActivity : FragmentActivity(), Host {
    private val vm: VaultViewModel by viewModels()

    private var pendingPerm: ((Boolean) -> Unit)? = null
    private var pendingCheck: (() -> Boolean)? = null
    private var pendingDelete: ((Boolean) -> Unit)? = null
    private var pendingPick: ((List<Uri>) -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            vm.suppressLock = false
            val cb = pendingPerm; val check = pendingCheck
            pendingPerm = null; pendingCheck = null
            cb?.invoke(check?.invoke() ?: false)
        }

    private val deleteLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            vm.suppressLock = false
            val cb = pendingDelete; pendingDelete = null
            cb?.invoke(r.resultCode == RESULT_OK)
        }

    private val pickLauncher = registerForActivityResult(PickFiles()) { uris ->
        vm.suppressLock = false
        val cb = pendingPick; pendingPick = null
        cb?.invoke(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Blocks screenshots and hides content in the recent-apps screen.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent { ObscuraTheme { ObscuraRoot(vm, this) } }
    }

    override fun onStart() {
        super.onStart()
        if (vm.stoppedWhileSuppressed) {
            vm.stoppedWhileSuppressed = false
            vm.suppressLock = false
        }
    }

    override fun onResume() {
        super.onResume()
        vm.resumeTick++
    }

    /** Lock only when the user really leaves the app, never when the app opens its own dialogs. */
    override fun onStop() {
        super.onStop()
        if (isChangingConfigurations) return
        if (vm.suppressLock) vm.stoppedWhileSuppressed = true else vm.lock()
    }

    // ---------- permissions ----------
    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun hasRead(): Boolean = when {
        Build.VERSION.SDK_INT >= 34 ->
            (granted(Manifest.permission.READ_MEDIA_IMAGES) && granted(Manifest.permission.READ_MEDIA_VIDEO)) ||
                granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 ->
            granted(Manifest.permission.READ_MEDIA_IMAGES) && granted(Manifest.permission.READ_MEDIA_VIDEO)
        else -> granted(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun readPerms(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
        )
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        Build.VERSION.SDK_INT >= 29 -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    override fun ensureReadAccess(cb: (Boolean) -> Unit) {
        if (hasRead()) { cb(true); return }
        pendingPerm = cb; pendingCheck = { hasRead() }
        vm.suppressLock = true
        permLauncher.launch(readPerms())
    }

    override fun ensureWriteAccess(cb: (Boolean) -> Unit) {
        if (Build.VERSION.SDK_INT >= 29 || granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) { cb(true); return }
        pendingPerm = cb; pendingCheck = { granted(Manifest.permission.WRITE_EXTERNAL_STORAGE) }
        vm.suppressLock = true
        permLauncher.launch(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }

    // ---------- removing originals from the gallery ----------
    override fun requestDelete(uris: List<Uri>, onDone: (Boolean) -> Unit) {
        var left: List<Uri> = uris
        val direct = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else Build.VERSION.SDK_INT < 29
        if (direct) {
            val failed = ArrayList<Uri>()
            for (u in uris) {
                try {
                    if (contentResolver.delete(u, null, null) == 0) failed.add(u)
                } catch (_: Exception) {
                    failed.add(u)
                }
            }
            left = failed
        }
        if (left.isEmpty()) { onDone(true); return }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(contentResolver, left)
                pendingDelete = onDone
                vm.suppressLock = true
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (_: Exception) {
                vm.suppressLock = false
                onDone(false)
            }
        } else {
            onDone(false)
        }
    }

    override fun pickFiles(cb: (List<Uri>) -> Unit) {
        pendingPick = cb
        vm.suppressLock = true
        pickLauncher.launch(Unit)
    }

    override fun sendEmail() {
        vm.suppressLock = true
        try {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:meafaq17@gmail.com"))
                .putExtra(Intent.EXTRA_SUBJECT, "Obscura help")
            startActivity(Intent.createChooser(i, "Contact support"))
        } catch (_: Exception) {
            vm.suppressLock = false
            vm.message = "No email app found. Write to meafaq17@gmail.com"
        }
    }

    override fun openAllFilesSettings() {
        if (Build.VERSION.SDK_INT < 30) return
        vm.suppressLock = true
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (_: Exception) {
                vm.suppressLock = false
            }
        }
    }

    override fun hasAllFilesAccess(): Boolean =
        Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()

    // ---------- biometrics ----------
    override fun canBiometric(): Boolean =
        BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS

    override fun authenticate(title: String, cb: (Boolean, String?) -> Unit) {
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    cb(true, null)
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON ||
                        errorCode == BiometricPrompt.ERROR_USER_CANCELED ||
                        errorCode == BiometricPrompt.ERROR_CANCELED
                    ) cb(false, null) else cb(false, errString.toString())
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setNegativeButtonText("Cancel")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        prompt.authenticate(info)
    }
}
