package com.afaq.obscura

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---------------------------------------------------------------- PIN pad
@Composable
fun PinPad(accent: Color, error: String?, onSubmit: (String) -> Unit, modifier: Modifier = Modifier) {
    var pin by remember { mutableStateOf("") }

    fun submit() {
        val p = pin
        pin = ""
        onSubmit(p)
    }

    fun press(d: String) {
        if (pin.length < 6) {
            pin += d
            if (pin.length == 6) submit()
        }
    }

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.height(24.dp)
        ) {
            repeat(6) { i ->
                Box(
                    Modifier.size(14.dp).clip(CircleShape)
                        .background(if (i < pin.length) accent else Pal.Surface2)
                )
            }
        }
        Text(
            error ?: " ", color = Pal.Error, fontSize = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 8.dp).height(18.dp)
        )
        for (row in listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))) {
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                for (d in row) PadKey(onClick = { press(d) }) { PadText(d) }
            }
            Spacer(Modifier.height(14.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            PadKey(onClick = { if (pin.isNotEmpty()) pin = pin.dropLast(1) }) { PadText("\u232B") }
            PadKey(onClick = { press("0") }) { PadText("0") }
            PadKey(onClick = { if (pin.length >= 4) submit() }, bg = accent) {
                Icon(Icons.Default.Check, null, tint = Color.Black)
            }
        }
    }
}

@Composable
private fun PadText(t: String) = Text(t, fontSize = 24.sp, color = Pal.Text, fontWeight = FontWeight.Medium)

@Composable
private fun PadKey(onClick: () -> Unit, bg: Color = Pal.Surface2, content: @Composable () -> Unit) {
    Box(
        Modifier.size(68.dp).clip(CircleShape).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

// ---------------------------------------------------------------- Pattern
@Composable
fun PatternLock(
    accent: Color,
    isError: Boolean,
    onComplete: (List<Int>) -> Unit,
    onTooShort: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selected = remember { mutableStateListOf<Int>() }
    var cur by remember { mutableStateOf<Offset?>(null) }
    val done by rememberUpdatedState(onComplete)
    val short by rememberUpdatedState(onTooShort)
    val color = if (isError) Pal.Error else accent

    Canvas(
        modifier.aspectRatio(1f).pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                selected.clear()

                fun hit(o: Offset) {
                    val cell = size.width / 3f
                    for (i in 0..8) {
                        val c = Offset((i % 3 + 0.5f) * cell, (i / 3 + 0.5f) * cell)
                        if ((o - c).getDistance() < cell * 0.3f && i !in selected) {
                            selected.add(i); break
                        }
                    }
                }

                cur = down.position
                hit(down.position)
                down.consume()
                do {
                    val event = awaitPointerEvent()
                    val ch = event.changes.firstOrNull() ?: break
                    if (ch.pressed) {
                        cur = ch.position
                        hit(ch.position)
                        ch.consume()
                    }
                } while (event.changes.any { it.pressed })
                cur = null
                val p = selected.toList()
                selected.clear()
                if (p.size >= 4) done(p) else if (p.isNotEmpty()) short()
            }
        }
    ) {
        val cell = size.width / 3f
        fun c(i: Int) = Offset((i % 3 + 0.5f) * cell, (i / 3 + 0.5f) * cell)
        for (k in 1 until selected.size) {
            drawLine(color, c(selected[k - 1]), c(selected[k]), strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round)
        }
        val end = cur
        if (end != null && selected.isNotEmpty()) {
            drawLine(color.copy(alpha = .55f), c(selected.last()), end, strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round)
        }
        for (i in 0..8) {
            val on = i in selected
            if (on) drawCircle(color.copy(alpha = .25f), 28.dp.toPx(), c(i))
            drawCircle(if (on) color else Pal.Muted.copy(alpha = .55f), if (on) 12.dp.toPx() else 7.dp.toPx(), c(i))
        }
    }
}

// ---------------------------------------------------------------- Fingerprint glyph
@Composable
fun FingerprintGlyph(color: Color, modifier: Modifier = Modifier.size(110.dp)) {
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val sw = size.width * 0.045f
        for ((i, r) in listOf(.14f, .26f, .38f, .5f).withIndex()) {
            val rad = size.width * r * 0.95f
            drawArc(
                color, startAngle = 200f + i * 12f, sweepAngle = 300f - i * 18f, useCenter = false,
                topLeft = Offset(c.x - rad, c.y - rad), size = Size(rad * 2, rad * 2),
                style = Stroke(sw, cap = StrokeCap.Round)
            )
        }
    }
}

// ---------------------------------------------------------------- Unlock screen
@Composable
fun UnlockScreen(vm: VaultViewModel, host: Host) {
    val sec = vm.security
    val bioOk = sec.bioEnabled && host.canBiometric()
    var tab by remember { mutableIntStateOf(if (bioOk) 2 else 0) }
    var error by remember { mutableStateOf<String?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) { now = System.currentTimeMillis(); delay(500) }
    }
    val remaining = ((sec.lockUntil() - now) / 1000L).coerceAtLeast(0L)
    val shownError = if (remaining > 0L) "Too many attempts. Try again in ${remaining}s" else error

    fun fail(msg: String) {
        sec.registerFail()
        error = if (sec.lockUntil() > System.currentTimeMillis()) "Too many attempts" else msg
    }

    LaunchedEffect(tab) {
        error = null
        if (tab == 2 && bioOk) {
            host.authenticate("Unlock Obscura") { ok, msg ->
                if (ok) vm.unlock() else if (msg != null) error = msg
            }
        }
    }

    val tabs = listOf("PIN" to Pal.Photos, "Pattern" to Pal.Settings, "Fingerprint" to Pal.Home)
    Column(
        Modifier.fillMaxSize().background(Pal.Bg).verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        Box(Modifier.size(64.dp).clip(CircleShape).background(Pal.Home.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Lock, null, tint = Pal.Home, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text("Obscura", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
        Text("Unlock your vault", fontSize = 14.sp, color = Pal.Muted)
        Spacer(Modifier.height(18.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Pal.Surface).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            tabs.forEachIndexed { i, (label, col) ->
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                        .background(if (tab == i) col else Color.Transparent)
                        .clickable { tab = i }.padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (tab == i) Color.Black else Pal.Muted)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        when (tab) {
            0 -> PinPad(Pal.Photos, shownError, onSubmit = { pin ->
                if (remaining == 0L) { if (sec.checkPin(pin)) vm.unlock() else fail("Wrong PIN") }
            })
            1 -> {
                Text(shownError ?: "Draw your pattern", color = if (shownError != null) Pal.Error else Pal.Muted, fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                PatternLock(
                    Pal.Settings, isError = shownError != null,
                    onComplete = { p -> if (remaining == 0L) { if (sec.checkPattern(p)) vm.unlock() else fail("Wrong pattern") } },
                    onTooShort = { error = "Connect at least 4 dots" },
                    modifier = Modifier.size(280.dp)
                )
            }
            else -> {
                FingerprintGlyph(Pal.Home)
                Spacer(Modifier.height(14.dp))
                if (bioOk) {
                    Text(error ?: "Touch the fingerprint sensor", color = if (error != null) Pal.Error else Pal.Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            host.authenticate("Unlock Obscura") { ok, msg ->
                                if (ok) vm.unlock() else if (msg != null) error = msg
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Pal.Home, contentColor = Color.Black)
                    ) { Text("Scan fingerprint") }
                } else {
                    Text(
                        "Fingerprint unlock is not turned on.\nUse your PIN or pattern, then enable it in Settings.",
                        color = Pal.Muted, fontSize = 14.sp, textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Setup / change credentials
enum class SetupMode { FULL, PIN, PATTERN }

@Composable
fun SetupFlow(mode: SetupMode, vm: VaultViewModel, host: Host, onDone: () -> Unit, onCancel: (() -> Unit)? = null) {
    var step by remember { mutableIntStateOf(if (mode == SetupMode.PATTERN) 2 else 0) }
    var tmpPin by remember { mutableStateOf("") }
    var tmpPat by remember { mutableStateOf<List<Int>>(emptyList()) }
    var err by remember { mutableStateOf<String?>(null) }
    val sec = vm.security

    val (title, sub) = when (step) {
        0 -> "Create a PIN" to "Choose 4 to 6 digits"
        1 -> "Confirm your PIN" to "Enter the same PIN again"
        2 -> "Draw a pattern" to "Connect at least 4 dots"
        3 -> "Confirm your pattern" to "Draw the same pattern again"
        else -> "Fingerprint unlock" to "Unlock faster with your fingerprint"
    }
    val accent = when (step) { 0, 1 -> Pal.Photos; 2, 3 -> Pal.Settings; else -> Pal.Home }

    Column(
        Modifier.fillMaxSize().background(Pal.Bg).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(20.dp))
        if (mode == SetupMode.FULL) Text("Welcome to Obscura", color = Pal.Home, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Pal.Text)
        Text(sub, fontSize = 14.sp, color = Pal.Muted)
        Spacer(Modifier.height(24.dp))
        when (step) {
            0 -> PinPad(accent, err, onSubmit = { p -> tmpPin = p; err = null; step = 1 })
            1 -> PinPad(accent, err, onSubmit = { p ->
                if (p == tmpPin) {
                    sec.setPin(p); err = null
                    if (mode == SetupMode.PIN) onDone() else step = 2
                } else { err = "PINs do not match. Start again"; step = 0 }
            })
            2, 3 -> {
                Text(err ?: " ", color = Pal.Error, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                PatternLock(
                    accent, isError = err != null,
                    onComplete = { p ->
                        if (step == 2) { tmpPat = p; err = null; step = 3 }
                        else if (p == tmpPat) {
                            sec.setPattern(p); err = null
                            if (mode == SetupMode.FULL && host.canBiometric()) step = 4 else onDone()
                        } else { err = "Patterns do not match. Try again"; step = 2 }
                    },
                    onTooShort = { err = "Connect at least 4 dots" },
                    modifier = Modifier.size(280.dp)
                )
            }
            else -> {
                FingerprintGlyph(accent)
                Spacer(Modifier.height(10.dp))
                Text(err ?: " ", color = Pal.Error, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        host.authenticate("Confirm your fingerprint") { ok, msg ->
                            if (ok) { sec.bioEnabled = true; onDone() } else err = msg ?: "Fingerprint not recognised"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Pal.Home, contentColor = Color.Black)
                ) { Text("Enable fingerprint") }
                TextButton(onClick = { onDone() }) { Text("Skip for now", color = Pal.Muted) }
            }
        }
        if (onCancel != null) {
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onCancel) { Text("Cancel", color = Pal.Muted) }
        }
    }
}
