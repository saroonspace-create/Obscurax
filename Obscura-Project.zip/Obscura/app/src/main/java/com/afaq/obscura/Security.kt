package com.afaq.obscura

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Stores salted PBKDF2 hashes of the PIN and pattern. Nothing is stored in plain text. */
class SecurityStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("obscura_security", Context.MODE_PRIVATE)

    val isSetup: Boolean get() = sp.contains("pin_h") && sp.contains("pat_h")

    var bioEnabled: Boolean
        get() = sp.getBoolean("bio", false)
        set(v) { sp.edit().putBoolean("bio", v).commit() }

    fun setPin(pin: String) = save("pin", pin)
    fun setPattern(p: List<Int>) = save("pat", p.joinToString("-"))
    fun checkPin(pin: String) = verify("pin", pin)
    fun checkPattern(p: List<Int>) = verify("pat", p.joinToString("-"))

    fun lockUntil(): Long = sp.getLong("lock_until", 0L)

    fun registerFail() {
        val fails = sp.getInt("fails", 0) + 1
        val e = sp.edit().putInt("fails", fails)
        if (fails >= 5) {
            val step = (fails - 5).coerceAtMost(4)
            e.putLong("lock_until", System.currentTimeMillis() + (30_000L shl step))
        }
        e.commit()
    }

    fun clearFails() {
        sp.edit().putInt("fails", 0).putLong("lock_until", 0L).commit()
    }

    private fun save(k: String, secret: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp.edit()
            .putString("${k}_s", b64(salt))
            .putString("${k}_h", b64(hash(secret, salt)))
            .commit()
    }

    private fun verify(k: String, secret: String): Boolean {
        val s = sp.getString("${k}_s", null) ?: return false
        val h = sp.getString("${k}_h", null) ?: return false
        val calc = hash(secret, Base64.decode(s, Base64.NO_WRAP))
        return MessageDigest.isEqual(calc, Base64.decode(h, Base64.NO_WRAP))
    }

    private fun hash(secret: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(secret.toCharArray(), salt, 50_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
}
