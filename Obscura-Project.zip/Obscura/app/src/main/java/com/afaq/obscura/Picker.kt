package com.afaq.obscura

import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** The app's own gallery browser: pick photos/videos to lock, no third-party picker involved. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryPicker(vm: VaultViewModel, host: Host, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf<Boolean?>(null) }
    var all by remember { mutableStateOf<List<GalleryMedia>?>(null) }
    var filter by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf(setOf<Uri>()) }
    var attempt by remember { mutableIntStateOf(0) }

    LaunchedEffect(attempt) { host.ensureReadAccess { granted = it } }
    LaunchedEffect(granted) {
        if (granted == true) all = withContext(Dispatchers.IO) { queryGallery(ctx) }
    }

    val shown = remember(all, filter) {
        all?.filter { filter == 0 || (filter == 1 && !it.video) || (filter == 2 && it.video) }
    }

    Column(Modifier.fillMaxSize().background(Pal.Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = Pal.Text) }
            Column(Modifier.weight(1f)) {
                Text("Choose items to lock", color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(if (selected.isEmpty()) "Tap to select" else "${selected.size} selected", color = Pal.Muted, fontSize = 12.sp)
            }
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All" to Pal.Home, "Photos" to Pal.Photos, "Videos" to Pal.Videos).forEachIndexed { i, (label, col) ->
                Text(
                    label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    color = if (filter == i) Color.Black else col,
                    modifier = Modifier.clip(RoundedCornerShape(50))
                        .background(if (filter == i) col else col.copy(alpha = .15f))
                        .clickable { filter = i }.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            val list = shown
            when {
                granted == false -> Column(
                    Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Obscura needs access to your photos and videos to show them here.", color = Pal.Muted, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = { granted = null; attempt++ },
                        colors = ButtonDefaults.buttonColors(containerColor = Pal.Photos, contentColor = Color.Black)
                    ) { Text("Allow access") }
                }
                list == null -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Pal.Photos)
                list.isEmpty() -> Text("No media found", color = Pal.Muted, modifier = Modifier.align(Alignment.Center))
                else -> LazyVerticalGrid(
                    GridCells.Adaptive(100.dp), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(list, key = { it.uri.toString() }) { m ->
                        val on = m.uri in selected
                        val col = if (m.video) Pal.Videos else Pal.Photos
                        val shape = RoundedCornerShape(12.dp)
                        Box(
                            Modifier.aspectRatio(1f).clip(shape)
                                .border(if (on) 3.dp else 1.dp, if (on) Color.White else col.copy(alpha = .6f), shape)
                                .clickable { selected = if (on) selected - m.uri else selected + m.uri }
                        ) {
                            Thumb("g:${m.uri}", Modifier.fillMaxSize()) {
                                if (m.video) Thumbs.videoUri(ctx, m.uri, 300) else Thumbs.imageUri(ctx, m.uri, 300)
                            }
                            if (m.video) {
                                Text(
                                    "\u25B6", color = Color.White, fontSize = 11.sp,
                                    modifier = Modifier.align(Alignment.BottomStart).padding(5.dp).clip(RoundedCornerShape(6.dp))
                                        .background(Pal.Videos.copy(alpha = .9f)).padding(horizontal = 6.dp, vertical = 1.dp)
                                )
                            }
                            if (on) {
                                Box(Modifier.fillMaxSize().background(col.copy(alpha = .35f)))
                                Box(
                                    Modifier.align(Alignment.TopEnd).padding(5.dp).size(22.dp).clip(CircleShape).background(Color.White),
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.Check, null, tint = Color.Black, modifier = Modifier.size(15.dp)) }
                            }
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().background(Pal.Surface).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TextButton(onClick = {
                val s = shown ?: emptyList()
                selected = if (s.isNotEmpty() && s.all { it.uri in selected }) selected - s.map { it.uri }.toSet()
                else selected + s.map { it.uri }
            }) { Text("Select all", color = Pal.Home) }
            Button(
                onClick = {
                    val picks = all?.filter { it.uri in selected } ?: emptyList()
                    onClose()
                    vm.importMedia(host, picks)
                },
                enabled = selected.isNotEmpty(),
                modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Pal.Photos, contentColor = Color.Black)
            ) { Text("Lock ${selected.size} item(s)", fontWeight = FontWeight.SemiBold) }
        }
    }
}
