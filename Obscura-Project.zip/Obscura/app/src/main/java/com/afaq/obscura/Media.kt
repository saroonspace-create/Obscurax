package com.afaq.obscura

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.util.LruCache
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream

/** Small, memory-safe thumbnail + image decoding with a shared cache. */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8).coerceAtMost(48L * 1024 * 1024).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val gate = Semaphore(3)

    fun peek(key: String): Bitmap? = cache.get(key)

    suspend fun load(key: String, block: () -> Bitmap?): Bitmap? {
        cache.get(key)?.let { return it }
        return gate.withPermit {
            withContext(Dispatchers.IO) {
                val b = try { block() } catch (_: Throwable) { null }
                if (b != null) cache.put(key, b)
                b
            }
        }
    }

    fun decodeImage(open: () -> InputStream?, maxPx: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxPx && bounds.outHeight / (sample * 2) >= maxPx) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = open()?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = try {
            open()?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        return rotate(bmp, orientation)
    }

    private fun rotate(b: Bitmap, o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return b
        }
        return try { Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true) } catch (_: Throwable) { b }
    }

    fun imageFile(f: File, maxPx: Int) = decodeImage({ f.inputStream() }, maxPx)
    fun imageUri(ctx: Context, u: Uri, maxPx: Int) = decodeImage({ ctx.contentResolver.openInputStream(u) }, maxPx)

    private fun frame(setup: (MediaMetadataRetriever) -> Unit, maxPx: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            setup(r)
            val f = r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(0) ?: return null
            val scale = maxPx.toFloat() / maxOf(f.width, f.height)
            if (scale < 1f) Bitmap.createScaledBitmap(f, (f.width * scale).toInt().coerceAtLeast(1), (f.height * scale).toInt().coerceAtLeast(1), true) else f
        } catch (_: Throwable) {
            null
        } finally {
            try { r.release() } catch (_: Throwable) {}
        }
    }

    fun videoFile(f: File, maxPx: Int) = frame({ it.setDataSource(f.absolutePath) }, maxPx)
    fun videoUri(ctx: Context, u: Uri, maxPx: Int) = frame({ it.setDataSource(ctx, u) }, maxPx)
}

data class GalleryMedia(val uri: Uri, val name: String, val size: Long, val date: Long, val video: Boolean)

/** Reads the phone gallery (photos + videos) so the app can show its own picker. */
fun queryGallery(ctx: Context): List<GalleryMedia> {
    val out = ArrayList<GalleryMedia>()
    fun q(collection: Uri, video: Boolean) {
        val proj = arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_ADDED
        )
        try {
            ctx.contentResolver.query(collection, proj, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                while (c.moveToNext()) {
                    out.add(
                        GalleryMedia(
                            ContentUris.withAppendedId(collection, c.getLong(iId)),
                            c.getString(iName) ?: "media", c.getLong(iSize), c.getLong(iDate), video
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
    }
    q(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false)
    q(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
    return out.sortedByDescending { it.date }
}
